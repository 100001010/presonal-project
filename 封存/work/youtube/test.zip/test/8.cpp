#include<iostream>
#include<cstdlib>
using namespace std;
int main(){
    srand(time(NULL));
    int i=rand();
    cout<<i;
}