#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm>
#include <random>
using namespace std;

class Book{
public: 
    Book(){     //這個就是constructor
    cout << " 我是示範" << endl;
    }
};

int main(){
    Book b1;
} 